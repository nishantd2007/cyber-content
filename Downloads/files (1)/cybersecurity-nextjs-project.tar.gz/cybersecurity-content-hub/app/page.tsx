import { getAllTopics, getTopicBySlug } from '@/lib/markdown';
import TopicAccordion from '@/components/TopicAccordion';

export default function Home() {
  const topicMetadata = getAllTopics();
  const topics = topicMetadata
    .map((meta) => getTopicBySlug(meta.slug))
    .filter((topic) => topic !== null);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
          <h1 className="text-2xl font-semibold mb-1">
            Cybersecurity Content Hub 2026
          </h1>
          <p className="text-sm text-muted-foreground">
            10 topics across X, LinkedIn, and Medium · Click to expand
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="space-y-2">
          {topics.map((topic) => (
            <TopicAccordion key={topic!.slug} topic={topic!} />
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 text-center text-sm text-muted-foreground">
          <p className="font-semibold mb-1">Cybersecurity Content Hub 2026</p>
          <p>10 Topics · 3 Platforms · Professional Content</p>
        </div>
      </footer>
    </div>
  );
}
