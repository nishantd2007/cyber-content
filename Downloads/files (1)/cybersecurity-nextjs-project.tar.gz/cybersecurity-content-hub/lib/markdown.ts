import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import type { Topic, TopicMetadata } from '@/types';

const contentDirectory = path.join(process.cwd(), 'content');

export function getAllTopics(): TopicMetadata[] {
  const fileNames = fs.readdirSync(contentDirectory);
  const topics = fileNames
    .filter((fileName) => fileName.endsWith('.md'))
    .map((fileName) => {
      const slug = fileName.replace(/\.md$/, '');
      const fullPath = path.join(contentDirectory, fileName);
      const fileContents = fs.readFileSync(fullPath, 'utf8');
      const { content } = matter(fileContents);

      const match = fileName.match(/Topic_(\d+)_(.*?)\.md/);
      const number = match ? parseInt(match[1]) : 0;
      
      const titleMatch = content.match(/^# (.+)$/m);
      const title = titleMatch ? titleMatch[1] : slug;

      return {
        slug,
        number,
        title,
      };
    })
    .sort((a, b) => a.number - b.number);

  return topics;
}

export function getTopicBySlug(slug: string): Topic | null {
  try {
    const fullPath = path.join(contentDirectory, `${slug}.md`);
    const fileContents = fs.readFileSync(fullPath, 'utf8');
    const { content } = matter(fileContents);

    // Extract title and number
    const titleMatch = content.match(/^# (.+)$/m);
    const title = titleMatch ? titleMatch[1] : slug;
    const numberMatch = slug.match(/Topic_(\d+)/);
    const number = numberMatch ? parseInt(numberMatch[1]) : 0;

    // Extract Twitter
    let twitterContent = '';
    const twitterMatch = content.match(/## 📱 X \(Twitter\)[^\n]*\n[^\n]*\n\n```\n([\s\S]*?)\n```/);
    if (twitterMatch) {
      twitterContent = twitterMatch[1].trim();
    }

    // Extract LinkedIn
    let linkedinContent = '';
    const linkedinMatch = content.match(/## 💼 LinkedIn Post[^\n]*\n[^\n]*\n\n([\s\S]*?)(?=\n---\n)/);
    if (linkedinMatch) {
      linkedinContent = linkedinMatch[1].trim();
    }

    // Extract Medium - use a better approach
    let mediumContent = '';
    const mediumMarker = '## 📝 Medium Article';
    const footerMarker = '\n---\n\n*Last Updated';
    
    const mediumStart = content.indexOf(mediumMarker);
    const footerStart = content.indexOf(footerMarker, mediumStart);
    
    if (mediumStart !== -1) {
      const mediumEndIndex = footerStart !== -1 ? footerStart : content.length;
      const mediumSection = content.substring(mediumStart, mediumEndIndex);
      
      // Remove the header line and metadata line
      const lines = mediumSection.split('\n');
      const filteredLines = lines.filter((line, index) => {
        // Skip first 3 lines (header, metadata, empty line)
        if (index < 3) return false;
        // Keep everything else
        return true;
      });
      
      mediumContent = filteredLines.join('\n').trim();
    }

    return {
      slug,
      number,
      title,
      twitter: {
        content: twitterContent,
        charCount: twitterContent.length,
      },
      linkedin: {
        content: linkedinContent,
        wordCount: linkedinContent.split(/\s+/).filter(w => w.length > 0).length,
      },
      medium: {
        content: mediumContent,
        wordCount: mediumContent.split(/\s+/).filter(w => w.length > 0).length,
      },
    };
  } catch (error) {
    console.error(`Error reading topic ${slug}:`, error);
    return null;
  }
}
